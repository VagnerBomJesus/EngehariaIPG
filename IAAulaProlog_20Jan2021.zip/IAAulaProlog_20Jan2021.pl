/* Intelig�ncia Artificial */
/* Exerc�cios Prolog */
/* Aula de 20/Janeiro/2021 */

/* Exerc�cio 1 */
animal(leao).
animal(tigre).
animal(vaca).
carnivoro(leao).
carnivoro(tigre).

/* Exerc�cio 2 */
/* Dating Agency Database */
person(bill,male).
person(george,male).
person(alfred,male).
person(carol,female).
person(margaret,female).
person(jane,female).

couple(A,B):-person(A,male),person(B,female).

/* Exerc�cio 4 */
paridade(N):- 0 is mod(N,2).

/* Exerc�cio 9 */
somaN(1,1).
somaN(N,S):-N>1, N1 is N-1, somaN(N1,S1), S is S1+N.
