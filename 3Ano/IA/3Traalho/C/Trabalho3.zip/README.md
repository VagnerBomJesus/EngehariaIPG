<h2>Procura Cega em Largura Primeiro</h2>

<h4>Considere o mapa da figura seguinte, com as respetivas ligações e distâncias quilométricas.</h4>

![image](https://user-images.githubusercontent.com/48354097/108565099-0a982400-72fc-11eb-8d68-64e1de4c5141.png)

<h4>Pretende-se que obtenha a solução para o problema de procura de um caminho entre os pontos B e E por aplicação da estratégia de procura cega em largura primeiro.</h4>

<h4>Apresente todos os passos do algoritmo, numerando os nós à medida que vão sendo analisados.</h4>
<h4> Apresente a solução e o custo finais.</h4>