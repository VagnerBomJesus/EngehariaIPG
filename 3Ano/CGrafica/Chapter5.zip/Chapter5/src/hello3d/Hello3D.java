package hello3d;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsConfiguration;

import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.Font3D;
import javax.media.j3d.FontExtrusion;
import javax.media.j3d.Material;
import javax.media.j3d.PointLight;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Text3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;

import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.universe.SimpleUniverse;

public class Hello3D extends Applet {
  public static void main(String s[]) {
	  new MainFrame(new Hello3D(), 640, 480);
  }
  
  public void init() {
	  GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
	  Canvas3D cv = new Canvas3D(gc);
	  
	  setLayout(new BorderLayout());
	  add(cv, BorderLayout.CENTER);
	  
	  BranchGroup bg = createSceneGraph();
	  bg.compile();
	  
	  SimpleUniverse su = new SimpleUniverse(cv);
	  su.getViewingPlatform().setNominalViewingTransform();
	  su.addBranchGraph(bg);
  }
  
  
  private BranchGroup createSceneGraph() {
	  BranchGroup root = new BranchGroup();
	
	  Font3D font = new Font3D(new Font("SansSerif", Font.PLAIN, 1), new FontExtrusion());
	  Text3D text = new Text3D(font, "Hello3D");
	  
	  Appearance ap = new Appearance();
	  ap.setMaterial(new Material());
			  
	  Shape3D shape = new Shape3D(text, ap);   
	  
	  root.addChild(shape);
	  
	  PointLight light = new PointLight(new Color3f(Color.WHITE), new Point3f(1f, 1f, 1f), new Point3f(1f, 0.1f, 0f));
	  
	  BoundingSphere bounds = new BoundingSphere();
	  light.setInfluencingBounds(bounds);
	  
	  root.addChild(light);
	  
	  return root;
  }
  
}
