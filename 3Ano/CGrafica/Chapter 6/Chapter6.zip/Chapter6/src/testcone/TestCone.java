package testcone;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.event.WindowEvent;

import javax.media.j3d.Appearance;
import javax.media.j3d.Background;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.ColoringAttributes;
import javax.media.j3d.Geometry;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.TriangleArray;
import javax.media.j3d.TriangleFanArray;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.universe.SimpleUniverse;

import shapes.Axes;
import shapes.Floor;

public class TestCone extends Frame {

	BoundingSphere bounds = new BoundingSphere();

	public static void main(String[] args) {
		Frame frame = new TestCone();
		frame.setPreferredSize(new Dimension(800, 800));
		frame.setTitle("Test Cone");
		frame.pack();
		frame.setVisible(true);
	}

	// The Frame class doesn't have a
	// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// A possible solution is to override the processWindowEvent method.
	protected void processWindowEvent(WindowEvent e) {
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			System.exit(0);
		}
	}

	public TestCone() {
		// Create a Canvas3D
		GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
		Canvas3D cv = new Canvas3D(gc);

		// Add the canvas to the frame
		setLayout(new BorderLayout());
		add(cv, BorderLayout.CENTER);

		// Add the canvas to the applet
		setLayout(new BorderLayout());
		add(cv, BorderLayout.CENTER);

		// Create the scene graph
		BranchGroup bg = createSceneGraph();
		bg.compile();

		// Create the root of the scene graph
		SimpleUniverse su = new SimpleUniverse(cv);

		// Configure the view
		su.getViewingPlatform().setNominalViewingTransform();

		// Add the scene graph to the root
		su.addBranchGraph(bg);

		// Add a OrbitBehavior to move the camera with the mouse
		OrbitBehavior orbit = new OrbitBehavior(cv);
		orbit.setSchedulingBounds(bounds);
		su.getViewingPlatform().setViewPlatformBehavior(orbit);
	}

	private BranchGroup createSceneGraph() {
		// The root of the scene graph
		BranchGroup root = new BranchGroup();

		// ***** Axes *****
		Shape3D axes = new Axes(new Color3f(Color.RED), 3, 0.9f);
		root.addChild(axes);
		
		// ***** floor *****
		Shape3D floor = new Floor(10, -2f, 2f, new Color3f(Color.GRAY), new Color3f(Color.LIGHT_GRAY), true);
		//root.addChild(floor);
		Transform3D tr = new Transform3D();
		tr.setTranslation(new Vector3f(0, -0.01f, 0));
		TransformGroup tg = new TransformGroup(tr);
		root.addChild(tg);
		tg.addChild(floor);

		// ***** Create a 3D object *****
		// Appearance
		Appearance ap = new Appearance();
		// ap.setMaterial(new Material());
		ap.setColoringAttributes(new ColoringAttributes(new Color3f(Color.WHITE), ColoringAttributes.SHADE_FLAT));
		ap.setPolygonAttributes(new PolygonAttributes(PolygonAttributes.POLYGON_LINE, PolygonAttributes.CULL_NONE, 0));

		// Geometry
		// Geometry geom = getConeGeometry1(2f, 1f, 10);
		Geometry geom = getConeGeometry2(2f, 1f, 10);
		//Geometry geom = new ConeGeometry(2f, 1f, 10);
		Shape3D shape = new Shape3D(geom, ap);

		// ***** Transformation *****
		tr = new Transform3D();
		tr.setScale(0.4);
		tg = new TransformGroup(tr);
		root.addChild(tg);
		// root.addChild(shape);
		tg.addChild(shape);

		// ***** Background *****
		Background background = new Background(0f, 0f, 0f);
		background.setApplicationBounds(bounds);
		root.addChild(background);
						
		return root;
	}

	private Geometry getConeGeometry1(float h, float r, int n) {
		// This version uses class TrinagleArray , so 3 vertices are
		// required for each triangle and there will be repeated vertices.

		TriangleArray ta = new TriangleArray(3 * n, GeometryArray.COORDINATES);
		Point3f apex = new Point3f(0, h, 0);
		Point3f p1 = new Point3f(r, 0, 0);
		int count = 0;
		double delta = 2 * Math.PI / n;
		for (int i = 1; i <= n; i++) {
			float x = (float) (r * Math.cos(i * delta));
			float z = (float) (r * Math.sin(i * delta));
			Point3f p2 = new Point3f(x, 0, z);
			ta.setCoordinate(count++, apex);
			ta.setCoordinate(count++, p1);
			ta.setCoordinate(count++, p2);
			p1 = p2;
		}
		return ta;
	}

	private Geometry getConeGeometry2(float h, float r, int n) {
		// This version uses class TriangleFanArray. In this case, the class
		// defines a new triangle based on a new vertex and previous vertices (last and
		// first),
		// which means that it is not necessary to repeat vertices.

		int[] stripVertexCounts = { n + 2 }; // 1 strip width n+2 vertices
		TriangleFanArray tfa = new TriangleFanArray(n + 2, GeometryArray.COORDINATES, stripVertexCounts);
		Point3f apex = new Point3f(0, h, 0);
		tfa.setCoordinate(0, apex);
		double delta = 2 * Math.PI / n;
		for (int i = 0; i <= n; i++) {
			float x = (float) (r * Math.cos(i * delta));
			float z = (float) (r * Math.sin(i * delta));
			Point3f p = new Point3f(x, 0, z);
			tfa.setCoordinate(i + 1, p);
		}
		return tfa;
	}

}
