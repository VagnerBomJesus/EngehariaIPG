/**
 * 
 */
/**
 * @author CC
 *
 */
package testinterpolators;