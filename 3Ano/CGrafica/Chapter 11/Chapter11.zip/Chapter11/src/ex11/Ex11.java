package ex11;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.event.WindowEvent;

import javax.media.j3d.Alpha;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.Background;
import javax.media.j3d.Billboard;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.PointLight;
import javax.media.j3d.RotPosPathInterpolator;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.universe.SimpleUniverse;

// Add the following classes to the respective packages of your CGLib3D
import appearance.MyMaterial;
import shapes.Axes;
import shapes.Floor;
import shapes.ImagePanel;
import shapes.MyObj;
import shapes.Points;
import utils.InterpolatorData;

public class Ex11 extends Frame {
	BoundingSphere bounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 4.0);

	public static void main(String[] args) {
		Frame frame = new Ex11();
		frame.setPreferredSize(new Dimension(800, 800));
		frame.setTitle("Ex11");
		frame.pack();
		frame.setVisible(true);
	}

	// The Frame class doesn't have a
	// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// A possible solution is to override the processWindowEvent method.
	protected void processWindowEvent(WindowEvent e) {
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			System.exit(0);
		}
	}

	public Ex11() {
		GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
		Canvas3D cv = new Canvas3D(gc);
		setLayout(new BorderLayout());
		add(cv, BorderLayout.CENTER);

		bounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 4.0);

		BranchGroup bg = createSceneGraph();
		bg.compile();
		SimpleUniverse su = new SimpleUniverse(cv);
		// su.getViewingPlatform().setNominalViewingTransform();

		Transform3D viewTr = new Transform3D();
		viewTr.lookAt(new Point3d(-2.5, 2.5, 2.5), new Point3d(0.0, 0.0, 0.0), new Vector3d(0.0, 1.0, 0.0));
		viewTr.invert();
		su.getViewingPlatform().getViewPlatformTransform().setTransform(viewTr);
		su.addBranchGraph(bg);

		OrbitBehavior orbit = new OrbitBehavior(cv);
		orbit.setSchedulingBounds(bounds);
		su.getViewingPlatform().setViewPlatformBehavior(orbit);

	}

	private BranchGroup createSceneGraph() {
		BranchGroup root = new BranchGroup();

		// Floor
		root.addChild(new Floor(21, -1.5f, 1.5f, new Color3f(Color.LIGHT_GRAY), new Color3f(Color.GRAY), true));

		// Axes
		root.addChild(new Axes(new Color3f(Color.RED), 3, 1f));

		// Object
		Appearance myObjApp = new Appearance();
		myObjApp.setMaterial(new MyMaterial(MyMaterial.BRONZE));
		MyObj myObj = new MyObj(0.1f, myObjApp);

		// TransformGroup to move the object
		TransformGroup moveTg = new TransformGroup();
		moveTg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		moveTg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

		root.addChild(moveTg);
		moveTg.addChild(myObj);

		// Interpolator
		Point3f[] positions = new Point3f[9]; // Array of positions that thefine the path

		positions[0] = new Point3f(-1f, 0f, 1f);

		positions[1] = new Point3f(-1f, 0f, -1f);
		positions[2] = new Point3f(-1f, 0f, -1f);

		positions[3] = new Point3f(1f, 0f, -1f);
		positions[4] = new Point3f(1f, 0f, -1f);

		positions[5] = new Point3f(1f, 0f, 1f);
		positions[6] = new Point3f(1f, 0f, 1f);

		positions[7] = new Point3f(-1f, 0f, 1f);
		positions[8] = new Point3f(-1f, 0f, 1f);

		Quat4f[] quats = new Quat4f[9]; // Array of quaternions that define the orientation betwen postions
		Quat4f q = new Quat4f();
		for (int i = 0; i < quats.length; i++)
			quats[i] = new Quat4f();

		// Create the orientation as a AxisAngle4f object and convert it to a quaternion
		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(0)));
		quats[0].add(q);

		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(0)));
		quats[1].add(q);
		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(-90)));
		quats[2].add(q);

		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(-90)));
		quats[3].add(q);
		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(-180)));
		quats[4].add(q);

		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(-180)));
		quats[5].add(q);
		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(-270)));
		quats[6].add(q);

		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(-270)));
		quats[7].add(q);
		q.set(new AxisAngle4f(0f, 1f, 0f, (float) Math.toRadians(0)));
		quats[8].add(q);

		float knots[] = new float[9]; // Array of knot values that define the times of the animation
		/*
		 * // Version with same time interval for all positions float a = 1f /
		 * (knots.length - 1); for (int i = 0; i < knots.length; i++) knots[i] = i * a;
		 */

		// Version with custom time intervals
		knots[0] = 0f;
		knots[1] = 0.1f;
		knots[2] = 0.15f;
		knots[3] = 0.6f;
		knots[4] = 0.7f;
		knots[5] = 0.8f;
		knots[6] = 0.9f;
		knots[7] = 0.95f;
		knots[8] = 1f;

		/*
		// With the InterpoalorData class is easier to set the data 
		InterpolatorData data = new InterpolatorData();
		data.add(new Point3f(-1.0f, 0.0f, 1.0f), 0.0f);

		data.add(new Point3f(-1.0f, 0.0f, -1.0f), 0.0f);
		data.add(new Point3f(-1.0f, 0.0f, -1.0f), -90.0f);

		data.add(new Point3f(1.0f, 0.0f, -1.0f), -90.0f);
		data.add(new Point3f(1.0f, 0.0f, -1.0f), -180.0f);

		data.add(new Point3f(1.0f, 0.0f, 1.0f), -180.0f);
		data.add(new Point3f(1.0f, 0.0f, 1.0f), -270.0f);

		data.add(new Point3f(-1.0f, 0.0f, 1.0f), -270.0f);
		data.add(new Point3f(-1.0f, 0.0f, 1.0f), 0.0f);
		
		RotPosPathInterpolator interpolator = new RotPosPathInterpolator(alpha, moveTg, new Transform3D(),
				data.getAlphas(), data.getOrientations(), data.getPositions());
		*/

		// Alpha alpha = new Alpha(-1, 10000);
		Alpha alpha = new Alpha(-1, 0, 2500, 10000, 0, 0); // Alpha with phaseDelayDuration

		Transform3D tr = new Transform3D();
		// tr.rotX(Math.toRadians(45));
		RotPosPathInterpolator interpolator = new RotPosPathInterpolator(alpha, moveTg, tr, knots, quats, positions);
		interpolator.setSchedulingBounds(bounds);
		moveTg.addChild(interpolator);

		// Use of the Points class to visualize the positions
		root.addChild(new Points(positions, new Point3f(0f, 0.25f, 0f), new Color3f(Color.RED), 15f));

		// Billboard
		TransformGroup bbTg = new TransformGroup();
		bbTg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		root.addChild(bbTg);

		Billboard bb = new Billboard(bbTg, Billboard.ROTATE_ABOUT_POINT, new Point3f(0f, 0f, 0f));
		bb.setSchedulingBounds(bounds);
		bbTg.addChild(bb);

		tr = new Transform3D();
		tr.setTranslation(new Vector3f(0f, 0.5f, 0f));
		TransformGroup tg = new TransformGroup(tr);
		ImagePanel imagePanel = new ImagePanel("images/T-Rex.png", 0.5f, this);

		tg.addChild(imagePanel);
		bbTg.addChild(tg);

		// Background
		Background background = new Background(new Color3f(Color.DARK_GRAY));
		background.setApplicationBounds(bounds);
		root.addChild(background);

		// Lights
		AmbientLight ablight = new AmbientLight(true, new Color3f(Color.GREEN));
		ablight.setInfluencingBounds(bounds);
		root.addChild(ablight);

		PointLight ptlight = new PointLight(new Color3f(Color.GREEN), new Point3f(2f, 2f, 2f), new Point3f(1f, 0f, 0f));
		ptlight.setInfluencingBounds(bounds);
		root.addChild(ptlight);

		return root;
	}

}