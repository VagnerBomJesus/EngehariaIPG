package gpath;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;

import javax.swing.JFrame;
import javax.swing.JPanel;

import cglib2d.shapes.Arrow;

public class GPath extends JFrame {

	public static void main(String[] args) {
		JFrame frame = new GPath();
		frame.setTitle("Shapes");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);

	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(400, 400));
		setBackground(Color.LIGHT_GRAY);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		// The following example uses the General Path method to create and draw an arrow shape.
		// The arrow shape is defined in terms of 4 parameters (like other shapes of Java 2D):
		// x, y - coordinates of the upper left corner;
		// w - with;
		// h - height.
		
		int x = 100;
		int y = 100;
		int w = 200;
		int h = 50;

		GeneralPath path = new GeneralPath();
		float x0 = x + w;
		float y0 = y + 0.5f * h;

		float x1 = x + 0.7f * w;
		float y1 = y + h;

		float x2 = x + 0.7f * w;
		float y2 = y + 0.7f * h;

		float x3 = x;
		float y3 = y + 0.7f * h;

		float x4 = x;
		float y4 = y + 0.3f * h;

		float x5 = x + 0.7f * w;
		float y5 = y + 0.3f * h;

		float x6 = x + 0.7f * w;
		float y6 = y;

		path.moveTo(x0, y0);
		path.lineTo(x1, y1);
		path.lineTo(x2, y2);
		path.lineTo(x3, y3);
		path.lineTo(x4, y4);
		path.lineTo(x5, y5);
		path.lineTo(x6, y6);
		// path.lineTo(x0, y0);
		path.closePath();

		g2.setColor(Color.BLUE);
		g2.fill(path);

		g2.setColor(Color.RED);
		g2.draw(path);
	}
}
