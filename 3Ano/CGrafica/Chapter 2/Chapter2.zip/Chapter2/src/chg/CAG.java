package chg;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;

import javax.swing.JFrame;
import javax.swing.JPanel;

import cglib2d.shapes.Arrow;
import gpath.GPath;


public class CAG extends JFrame {
	public static void main(String[] args) {
		JFrame frame = new CAG();
		frame.setTitle("CAG");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(760, 400));
		setBackground(Color.LIGHT_GRAY);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		Shape s1 = new Ellipse2D.Double(0, 0, 100, 100);
	    Shape s2 = new Ellipse2D.Double(60, 0, 100, 100);
	    
	    // The method Constructive Area Geometry is implemented in class Area.
	    // So, shapes must be transformed into Area objects.
	    Area a1 = new Area(s1);
	    Area a2 = new Area(s2);
	    
	    // Draw of the initial objects
	    g2.translate(20, 50);
	    g2.draw(a1);
	    g2.draw(a2);
	    
	    // Example of adding 2 objects. 
	    g2.translate(0,200);
	    a1.add(a2);
	    g2.fill(a1);
	    
	    // Example of intersecting 2 objects. 
	    g2.translate(180,0);
	    a1 = new Area(s1);
	    a1.intersect(a2);
	    g2.fill(a1);
	    
	    // Example of subtracting 2 objects.
	    g2.translate(180,0);
	    a1 = new Area(s1);
	    a1.subtract(a2);
	    g2.fill(a1);
	    
	    // Example of the exclusive or operation.
	    g2.translate(180,0);
	    a1 = new Area(s1);
	    a1.exclusiveOr(a2);
	    g2.fill(a1);
	}
}

