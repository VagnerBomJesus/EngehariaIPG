package curves;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Curves extends JFrame {
	public static void main(String s[]) {
		JFrame frame = new Curves();
		frame.setTitle("Curves");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(400, 400));
		setBackground(Color.LIGHT_GRAY);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		//drawCircle1(g2);
		//drawCircle2(g2);
		drawCurve(g2);
	}

	private void drawCircle1(Graphics2D g2) {
		// Draw of a circle using an equation y = f(x).
		// y = y0 +- sqrt(r^2 - (x-x0)^2))
		// The use of this type of equation normally does't work because different values of x give the same y. 
		// This is because we are using a raste ssytem with e finit resolution of pixels.  
		g2.translate(200, 200);
		g2.setColor(Color.RED);

		int x = 0;
		int y = 0;
		int r = 100;

		// The result is not good. The circle has gaps.  
		for (x = -r; x <= r; x++) {
			y = (int) Math.sqrt(r * r - x * x);
			g2.drawLine(x, y, x, y);
			y = (int) -Math.sqrt(r * r - x * x);
			g2.drawLine(x, y, x, y);
		}
	}

	private void drawCircle2(Graphics2D g2) {
		// This version uses the parametric equations of the circle.
		// x = r x cos(t)
		// y = r x sin(t)
		// 0 <= t <= 2 x Pi 
		// The curve is approximated with a set of points that are connected by line segments.
		g2.translate(200, 200);
		g2.setColor(Color.RED);

		int r = 100;  // Radius of the circle.
		int points = 80; // The greater the number of points, the greater the resolution of the curve.

		// First point for t = 0.
		int x1 = (int) (r * Math.cos(0));
		int y1 = (int) (r * Math.sin(0));
		int x2;
		int y2;

		// Increment of t.
		double dt = 2 * Math.PI / points;

		// Calculate the remaining points of the curve.
		for (int i = 1; i <= points; i++) {
			// Next t.
			double t = i * dt;
			
			// Next point of the curve.
			x2 = (int) (r * Math.cos(t));
			y2 = (int) (r * Math.sin(t));
			
			// Connect next point with last point.  
			g2.drawLine(x1, y1, x2, y2);
			
			// Next point becomes last point.
			x1 = x2;
			y1 = y2;
		}
	}

	private void drawCurve(Graphics2D g2) {
		// The code of function drawCircle2() can be generalized to draw any curve with known parametric equations.
		// For example, if curve has the following parametric equations 
		//x=100 x cos(3t)
		//y=100 x sin(2t)
		//0≤t≤2π

		g2.translate(200, 200);
		g2.setColor(Color.RED);

		double tmin = 0; // Minimum value of t.
		double tmax = 2 * Math.PI;  //Maximum value of t.
		int points = 80;  // The greater the number of points, the greater the resolution of the curve.

		// First point for t = 0.
		int x1 = (int) (100 * Math.cos(3 * tmin));
		int y1 = (int) (100 * Math.sin(2 * tmin));
		int x2;
		int y2;

		// Increment of t.
		double dt = (tmax - tmin) / points;

		// Calculate the remaining points of the curve.
		for (int i = 1; i <= points; i++) {
			// Next t.
			double t = i * dt;
			
			// Next point of the curve.
			x2 = (int) (100 * Math.cos(3*t));
			y2 = (int) (100 * Math.sin(2*t));
			
			// Connect next point with last point.  
			g2.drawLine(x1, y1, x2, y2);
			
			// Next point becomes last point.
			x1 = x2;
			y1 = y2;
		}
	}
}