package animation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class Animation extends JFrame implements ActionListener {

	PrinterJob pj;
	MyPanel panel;

	public static void main(String[] args) {
		JFrame frame = new Animation();
		frame.setTitle("Animation");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.pack();
		frame.setVisible(true);
	}

	public Animation() {
		JMenuBar mb = new JMenuBar();
		setJMenuBar(mb);

		JMenu menu = new JMenu("File");
		JMenuItem mi = new JMenuItem("Print");
		mi.addActionListener(this);
		menu.add(mi);
		menu.addSeparator();
		mi = new JMenuItem("Exit");
		mi.addActionListener(this);
		menu.add(mi);
		mb.add(menu);

		panel = new MyPanel();
		getContentPane().add(panel);

		pj = PrinterJob.getPrinterJob();
		pj.setPrintable(panel);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if ("Print".equals(cmd)) {
			if (pj.printDialog()) {
				try {
					pj.print();
				} catch (PrinterException ex) {
					ex.printStackTrace();
				}
			}
		} else if ("Exit".equals(cmd)) {
			System.exit(0);
		}
	}
}

class MyPanel extends JPanel implements Runnable, Printable {

	AffineTransform at = new AffineTransform();
	int ang = 0;

	public MyPanel() {
		setPreferredSize(new Dimension(400, 400));
		setBackground(Color.WHITE);

		Thread thread = new Thread(this);
		thread.start();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		drawFrame(g2);

	}

	private void drawFrame(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;

		Shape s1 = new Rectangle2D.Double(-50, -50, 100, 100);

		// Frame Rendering
		at.setToTranslation(200, 200);
		at.rotate(Math.toRadians(ang));
		s1 = at.createTransformedShape(s1);
		g2.setColor(Color.RED);
		g2.fill(s1);
	}

	@Override
	public void run() {
		while (true) {

			// Frame Update

			ang += 5 % 360;
			repaint();
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {

		switch (pageIndex) {
		case 0:
			drawFrame(graphics);
			break;

		default:
			return NO_SUCH_PAGE;
		}
		return PAGE_EXISTS;
	}

}
