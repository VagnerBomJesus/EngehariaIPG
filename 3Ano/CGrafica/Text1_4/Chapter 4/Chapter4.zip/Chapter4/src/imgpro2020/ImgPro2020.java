package imgpro2020;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.color.ColorSpace;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ColorConvertOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.RescaleOp;
import java.awt.image.WritableRaster;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class ImgPro2020 extends JFrame implements ActionListener {

	public static void main(String[] args) {
		JFrame frame = new ImgPro2020();
		frame.setTitle("ImgPro2020");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}

	ImagePanel imageSrc, imageDst;
	JFileChooser fc = new JFileChooser();

	public ImgPro2020() {
		// Menus
		JMenuBar mb = new JMenuBar();
		setJMenuBar(mb);

		JMenu menu = new JMenu("File");
		JMenuItem mi = new JMenuItem("Open image");
		mi.addActionListener(this);
		menu.add(mi);
		mi = new JMenuItem("Save image");
		mi.addActionListener(this);
		menu.add(mi);
		menu.addSeparator();
		mi = new JMenuItem("Exit");
		mi.addActionListener(this);
		menu.add(mi);
		mb.add(menu);

		menu = new JMenu("Process");
	    mi = new JMenuItem("Copy");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Smooth");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Sharpen");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Edge");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Rescale");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Rotate");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Gray scale");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mi = new JMenuItem("Gray scale 2");
	    mi.addActionListener(this);
	    menu.add(mi);
	    mb.add(menu);
		
		// Panels
		Container cp = this.getContentPane();
		cp.setLayout(new FlowLayout());
		imageSrc = new ImagePanel();
		imageDst = new ImagePanel();
		cp.add(imageSrc);
		cp.add(imageDst);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if ("Open image".equals(cmd)) {
			int retval = fc.showOpenDialog(this);
			if (retval == JFileChooser.APPROVE_OPTION) {
				try {
					BufferedImage bi = ImageIO.read(fc.getSelectedFile());
					imageSrc.setImage(bi);
					pack();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		} else if ("Save image".equals(cmd)) {

			int retval = fc.showSaveDialog(this);
			if (retval == JFileChooser.APPROVE_OPTION) {
				try {
					ImageIO.write(imageDst.getImage(), "png", fc.getSelectedFile());
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		} else if ("Exit".equals(cmd)) {
			System.exit(0);
		} else if ("Copy".equals(cmd)) {
			imageSrc.setImage(imageDst.getImage());
		} else {
			process(cmd);
		}
	}

	void process(String opName) {
		BufferedImageOp op = null;
		if (opName.equals("Smooth")) {
			float[] data = new float[9];
			for (int i = 0; i < 9; i++)
				data[i] = 1.0f / 9.0f;
			Kernel ker = new Kernel(3, 3, data);
			op = new ConvolveOp(ker);
		} else if (opName.equals("Sharpen")) {
			float[] data = { 0f, -1f, 0f, -1f, 5f, -1f, 0f, -1f, 0f };
			Kernel ker = new Kernel(3, 3, data);
			op = new ConvolveOp(ker);
		} else if (opName.equals("Edge")) {
			float[] data = { 0f, -1f, 0f, -1f, 4f, -1f, 0f, -1f, 0f };
			Kernel ker = new Kernel(3, 3, data);
			op = new ConvolveOp(ker);
		} else if (opName.equals("Rescale")) {
			op = new RescaleOp(1.5f, 0.0f, null);
		} else if (opName.equals("Gray scale")) {
			op = new ColorConvertOp(ColorSpace.getInstance(ColorSpace.CS_GRAY), null);
		} else if (opName.equals("Gray scale 2")) {
			//imageDst.setImage(RGBToGray(imageSrc.getImage()));
			imageDst.setImage(Binarization(imageSrc.getImage()));
			pack();
		} else if (opName.equals("Rotate")) {
			AffineTransform xform = new AffineTransform();
			xform.setToRotation(Math.PI / 6);
			op = new AffineTransformOp(xform, AffineTransformOp.TYPE_BILINEAR);
		}
		
		if(op != null) {
		  BufferedImage bi = op.filter(imageSrc.getImage(), null);
		  imageDst.setImage(bi);
		  pack();
		}
	}
	
	BufferedImage RGBToGray(BufferedImage imgIn) {
		BufferedImage imgOut = new BufferedImage(imgIn.getWidth(), imgIn.getHeight(), imgIn.getType());
		
		WritableRaster rasterImgIn = imgIn.getRaster();
		WritableRaster rasterImgOut = imgOut.getRaster();
		
		int[] rgba = new int[4];
		
		for(int x=0; x<imgIn.getWidth(); x++) {
			for(int y=0; y<imgIn.getHeight(); y++) {
				rasterImgIn.getPixel(x, y, rgba);
				
				int gray = (int) ((rgba[0] + rgba[1] + rgba[2]) / 3f);
				
				rgba[0] = rgba[1] = rgba[2] = gray;
				
				/*
				if(gray > 150) {
					rgba[0] = rgba[1] = rgba[2] = 255;
				}
				else {
					rgba[0] = rgba[1] = rgba[2] = 0;
				}
				*/
				
				rasterImgOut.setPixel(x, y, rgba);				
			}
		}
		return imgOut;		
	}
	
	BufferedImage Binarization(BufferedImage imgIn) {
		BufferedImage imgOut = new BufferedImage(imgIn.getWidth(), imgIn.getHeight(), imgIn.getType());
		
		WritableRaster rasterImgIn = imgIn.getRaster();
		WritableRaster rasterImgOut = imgOut.getRaster();
		
		int[] rgba = new int[4];
		
		for(int x=0; x<imgIn.getWidth(); x++) {
			for(int y=0; y<imgIn.getHeight(); y++) {
				rasterImgIn.getPixel(x, y, rgba);
				
				
				if(rgba[0] > 150) {
					rgba[0] = 255;
				}
				else {
					rgba[0] = 0;
				}
				
				rasterImgOut.setPixel(x, y, rgba);				
			}
		}
		return imgOut;		
	}
}

class ImagePanel extends JPanel {
	BufferedImage image = null;

	public ImagePanel() {
		setPreferredSize(new Dimension(256, 256));
		setBackground(Color.WHITE);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		if (image != null)
			g2.drawImage(image, 0, 0, this);
		else
			g2.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
	}

	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage bi) {
		image = bi;
		setPreferredSize(new Dimension(bi.getWidth(), bi.getHeight()));
		invalidate();
		repaint();
	}
}
