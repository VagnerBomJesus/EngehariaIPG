package moveshape;

/*
 * MoveShape.java
 *
 * @author ccarreto 
 * �ltima revis�o em 01/10/2015
 *
 * Esta aplica��o demonstra como mover Shapes usando o rato ou o teclado, e 
 * como detectar a colis�o entre Shapes.
 * Para mover a Shape Cora��o clicar com o rato na Shape e arrastar, ou 
 * usar as teclas das setas.
 * Caso a Shape Cora��o colida com a Shape do circulo a cor de ambas � alterada.
 * 
 */


import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;

import cglib2d.shapes.Heart;

public class MoveShape extends JFrame {
    
  public static void main(String s[]) {
    JFrame frame = new MoveShape();
    frame.setTitle("MoveShape");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    JPanel panel = new MyPanel();
    frame.getContentPane().add(panel);
    frame.pack();
    frame.setVisible(true);
  }
}

//Para processar os eventos gerados pelo teclado fazemos com que a classe Panel 
//implemente a classe KeyListener.
//Para processar os eventos gerados pelo rato fazemos com que a classe Panel 
//implemente as classes MouseListener e MouseMotionListener.

class MyPanel extends JPanel implements KeyListener , MouseListener, MouseMotionListener {
  
  int firstX, firstY; //Coordenadas do cursor do rato ao selecionar a shape.
  int deltaX, deltaY; //Desloca��o sofrida pela shape ao arrastr o rato ou ao clicar nas setas.
  boolean selected = false; //Flag para indicar se a shape foi seleccioanda pelo rato (se o rato foi premido estando o curso dentro da Shape).
  boolean colision = false; //Flag que indica se h� ou n�o interse��o entre as duas shapes. 
          
  AffineTransform at = new AffineTransform(); // Objeto para aplicar a tranla��o � Shape
  
  //Cria��o de duas Shapes
  //Shape s1 = new Arrow(10, 10, 50, 50);   //A Shape que se pretende mover
  Shape s1 = new Heart(10, 10, 100, 100);   //A Shape que se pretende mover
  Shape s2 = new Ellipse2D.Float(200-50, 200-50, 100, 100) ; //A Shape que fica est�tica
  
    
  public MyPanel() {
    //Configura��o das dimens�es e cor de fundo do painel.
    setPreferredSize(new Dimension(400, 400));
    setBackground(Color.LIGHT_GRAY);
      
    //Para que seja poss�vel detectar eventos do teclado no painel este tem que 
    //poder receber focus. No caso da aplica��o ser executada como uma applet � 
    //necess�rio clicar na applet para que esta receba focus e passe a processar
    //os eventos do teclado.
    this.setFocusable(true); //Permitir que o painel receba focus.
    
    addKeyListener(this); //Escutar os eventos relacionados com o teclado.  
    addMouseListener(this); //Escutar os eventos relacionados com os bot�es do rato.
    addMouseMotionListener(this); //Escutar os eventos relacionados com o movimento do rato.
  }
  
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;
    
    g2.drawRect(0, 0, 399, 399);

    //Desenha a shape 2
    if(colision) g2.setColor(Color.RED);
    else g2.setColor(Color.BLUE);
    g2.fill(s2);
    g2.draw(s2.getBounds());
    
    //Desenho do centro da shape circulo
    //g2.setColor(Color.GREEN);
    //g2.drawLine((int)s2.getBounds().getCenterX(), (int)s2.getBounds().getCenterY(), (int)s2.getBounds().getCenterX(), (int)s2.getBounds().getCenterY());
    
    //Desenha a shape s1
    if(colision) g2.setColor(Color.RED);
    else g2.setColor(Color.GREEN);
    g2.fill(s1);
    g2.draw(s1.getBounds());
  }
  
    
   //*************************************************************************     
   //* Processamento dos eventos relacionados com os bot�es do rato.
   //*************************************************************************
    public void mousePressed(MouseEvent e) {
      if(s1.contains(e.getX(), e.getY())) {
        firstX = e.getX();
        firstY = e.getY();
        selected = true;
      }  
      else selected = false;
    }

    public void mouseReleased(MouseEvent e) {}         
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    //*************************************************************************     
    //* Processamento dos eventos relacionados com o movimento do rato.
    //*************************************************************************     
    public void mouseDragged(MouseEvent e) {
      if(selected) {
          deltaX = e.getX() - firstX;
          deltaY = e.getY() - firstY;
          updateLocationAndDetectColision();
      }
    }

    public void mouseMoved(MouseEvent e) {}    

    //*************************************************************************     
    //* Processamento dos eventos relacionado com o teclado.
    //*************************************************************************     
    public void keyTyped(KeyEvent e) {
      //Sai do programa caso seja clicada a tecla escape.
      if (e.getKeyChar() == 27) {
        System.exit(0);
      }
    }

    public void keyPressed(KeyEvent e) {
      if (e.getKeyCode() == KeyEvent.VK_LEFT) {
        deltaX = -5;
      }
      if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
        deltaX = 5;
      }
      if (e.getKeyCode() == KeyEvent.VK_UP) {
        deltaY = -5;
      }
      if (e.getKeyCode() == KeyEvent.VK_DOWN) {
        deltaY = 5;
      }

      updateLocationAndDetectColision();
    }

   public void keyReleased(KeyEvent e) {}

   //*************************************************************************     
   //* Atualiza��o da posi��o da shape s1 e dete��o de colis�o entre as shapes
   //*************************************************************************
   public void updateLocationAndDetectColision(){
     
	 //Atualiza��o da localiza��o da shape s1   
     at.setToTranslation(deltaX, deltaY);
     s1 = at.createTransformedShape(s1);
      
     firstX += deltaX;
     firstY += deltaY;
     deltaX = 0;
     deltaY = 0;
   
     
     //Seguem-se duas vers�es para dete��o da colis�o entre as duas shapes:

     //Vers�o com base na interse��o dos ret�ngulos que inglobam cada shape 
     if(s1.intersects(s2.getBounds())) colision = true;
     else colision = false;
     
     //Vers�o com base na interse��o entre um dado ponto e o interior da shape
     //O ponto corresponde ao centro da shape circulo 
     //Point2D p = new Point2D.Double(s2.getBounds().getCenterX(), s2.getBounds().getCenterY());
     //if(s1.contains(p)) colision = true;
     //else colision = false;
     
     repaint();
   } 
}
