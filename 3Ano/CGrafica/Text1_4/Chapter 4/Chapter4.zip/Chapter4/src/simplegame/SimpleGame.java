package simplegame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;

import cglib2d.shapes.Arrow;

/**
 * A simple game demostrationg Shapes and Transformations.
 * 
 * @author ccarreto Last rev. 20/11/2016
 *
 */
public class SimpleGame extends JApplet {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Simple Game");
		JApplet applet = new SimpleGame();
		applet.init();
		frame.getContentPane().add(applet);
		frame.pack();
		frame.setVisible(true);
	}

	public void init() {
		JPanel panel = new MyPanel();
		getContentPane().add(panel);
	}
}

class MyPanel extends JPanel implements Runnable, KeyListener {

	// Animated objects
	Shape obj1 = null;
	Shape obj2 = null;
	Shape obj3 = null;
	Shape obj4 = null;
	float ang1 = 0;

	// Finishing point
	Shape arrow = null;

	// Player
	Shape player = null;
	int r = 15;
	int tx = 60, ty = 340;
	int vx = 0, vy = 0;
	int deltatx = 0, deltaty = 0;
	int p = 3;

	// Transformation
	AffineTransform at = new AffineTransform();

	public MyPanel() {
		setPreferredSize(new Dimension(400, 400));
		this.addKeyListener(this);
		this.setFocusable(true);

		Thread thread = new Thread(this);
		thread.start();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		// === Draw game state ===
		g2.setColor(Color.BLACK);
		g2.fillRect(0, 0, 400, 400);

		// Initialize objects
		obj1 = new Rectangle2D.Double(-100, -10, 200, 20);
		obj2 = new Rectangle2D.Double(-10, -100, 20, 200);
		obj3 = new Rectangle2D.Double(-100, -10, 200, 20);
		obj4 = new Rectangle2D.Double(-10, -100, 20, 200);
		player = new Ellipse2D.Double(-r, -r, 2 * r, 2 * r);

		arrow = new Arrow(-25, -25, 50, 50);

		// Draw finishing point
		g2.setColor(Color.GREEN);
		at.setToIdentity();
		at.translate(370, 30);
		//at.rotate(Math.toRadians(90));
		arrow = at.createTransformedShape(arrow);
		g2.fill(arrow);

		// Draw RED cross
		g2.setColor(Color.RED);
		at.setToIdentity();
		at.translate(120, 120);
		at.rotate(Math.toRadians(ang1));
		obj1 = at.createTransformedShape(obj1);
		g2.fill(obj1);
		obj2 = at.createTransformedShape(obj2);
		g2.fill(obj2);

		// Draw BLUE cross
		g2.setColor(Color.BLUE);
		at.setToIdentity();
		at.translate(280, 280);
		at.rotate(Math.toRadians(-ang1));
		obj3 = at.createTransformedShape(obj3);
		g2.fill(obj3);
		obj4 = at.createTransformedShape(obj4);
		g2.fill(obj4);

		// Draw player
		g2.setColor(Color.YELLOW);
		at.setToIdentity();
		at.translate(tx, ty);
		player = at.createTransformedShape(player);
		g2.fill(player);

		// Draw bounds
		/*
		g2.draw(player.getBounds2D());
		g2.draw(obj1.getBounds2D());
		g2.draw(obj2.getBounds2D());
		g2.draw(obj4.getBounds2D());
		g2.draw(player.getBounds2D());
		*/
	}

	@Override
	public void run() {
		while (true) {

			// === Update game state ===
			ang1 = (ang1 + 0.5f) % 360;

			//System.out.println("V: " + ang1);
			
			// Collision with panel limits
			if (tx - r < 0)
				tx = r;
			if (tx + r > 400)
				tx = 400 - r;
			if (ty - r < 0)
				ty = r;
			if (ty + r > 400)
				ty = 400 - r;

			// Collision with objects
			if (obj1 != null) {

				// Version using intersection
				// if (player.intersects(obj1.getBounds2D())
				// || player.intersects(obj2.getBounds2D())
				// || player.intersects(obj3.getBounds2D())
				// || player.intersects(obj4.getBounds2D())) {
				// tx = 60;
				// ty = 340;
				// }

				// Version using contains
				if (obj1.contains(tx, ty) || obj2.contains(tx, ty) || obj3.contains(tx, ty) || obj4.contains(tx, ty)) {
					// Return to starting point
					tx = 60;
					ty = 340;
					// Write GAME OVER
				}

				
				if (arrow != null && arrow.contains(tx, ty)) {
					// Return to starting point
					tx = 60;
					ty = 340;
					// Write YOU WIN
				}
			}

			tx = tx + vx;
			ty = ty + vy;

			repaint();
			try {
				Thread.sleep(1000 / 60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();
		switch (keyCode) {

		case KeyEvent.VK_LEFT:
			// tx -= p;
			vx = -1;
			vy = 0;
			break;
		case KeyEvent.VK_RIGHT:
			// tx += p;
			vx = 1;
			vy = 0;
			break;
		case KeyEvent.VK_UP:
			// ty -= p;
			vx = 0;
			vy = -1;
			break;
		case KeyEvent.VK_DOWN:
			// ty += p;
			vx = 0;
			vy = 1;
			break;
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		vx = 0;
		vy = 0;
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}
}