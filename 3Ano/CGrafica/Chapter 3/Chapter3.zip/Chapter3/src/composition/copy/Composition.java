package composition.copy;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Composition extends JFrame {

	public static void main(String[] args) {
		JFrame frame = new Composition();
		frame.setTitle("Composition");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		// setPreferredSize(new Dimension(400, 400));
		setPreferredSize(new Dimension(640, 480));
		setBackground(Color.WHITE);
	}

	public void paintComponent1(Graphics g) {
		// Demonstration of the composition of transformations.
		// Notice that the composition of transformations is not commutative.

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		int w = getWidth();
		int h = getHeight();
		drawAxis(g2, Color.RED);

		g2.translate(w / 2, h / 2);
		g2.rotate(Math.toRadians(30));
		drawAxis(g2, Color.BLUE);
		Shape r = new Rectangle2D.Double(-50, -50, 100, 100);
		g2.fill(r);

		// The composition of transformations is not commutative
		// g2.rotate(Math.toRadians(30));
		// g2.translate(w/2, h/2);
		// drawAxis(g2, Color.BLUE);
		// Shape r = new Rectangle2D.Double(-50, -50, 100, 100);
		// g2.fill(r);
	}

	public void paintComponent2(Graphics g) {
		// Demonstration and how to restore a previous graphical context.
		// In this case we simply store and activate previous contexts when needed.

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		int w = getWidth();
		int h = getHeight();
		drawAxis(g2, Color.RED);

		// Save the graphical context
		AffineTransform oldTransform = g2.getTransform();

		g2.translate(w / 2, h / 2);
		g2.rotate(Math.toRadians(30));
		drawAxis(g2, Color.BLUE);
		Shape r = new Rectangle2D.Double(-50, -50, 100, 100);
		g2.fill(r);

		// Restore the graphical context
		g2.setTransform(oldTransform);

		g2.rotate(Math.toRadians(30));
		g2.translate(w / 2, h / 2);
		drawAxis(g2, Color.GREEN);
		r = new Rectangle2D.Double(-50, -50, 100, 100);
		g2.fill(r);
	}

	public void paintComponent3(Graphics g) {
		// Demonstration and how to restore a previous graphical context.
		// In this case we manage the graphical contexts with a stack.

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		int w = getWidth();
		int h = getHeight();
		drawAxis(g2, Color.RED);

		g2 = this.push(g2);
		// The composition of transformations is not commutative
		g2.translate(w / 2, h / 2);
		g2.rotate(Math.toRadians(30));
		drawAxis(g2, Color.BLUE);
		Shape r = new Rectangle2D.Double(-50, -50, 100, 100);
		g2.fill(r);

		g2 = this.pop();
		g2.rotate(Math.toRadians(30));
		g2.translate(w / 2, h / 2);
		drawAxis(g2, Color.GREEN);
		r = new Rectangle2D.Double(-50, -50, 100, 100);
		g2.fill(r);
	}

	public void paintComponent4(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		g2.translate(60, 60);
		drawAxis(g2, Color.BLUE);

		// Draw of a square
		Shape shape1 = new Rectangle2D.Double(100, 200, 50, 50);
		g2.setColor(Color.BLUE);
		g2.fill(shape1);
		g2.draw(shape1);

		// Composition of transformations to rotate the square
		// around point (100, 200)
		// Notice that the axes are also transformed because the
		// composition is applied to the axes.
		g2.translate(100, 200);
		g2.rotate(Math.PI / 6);
		g2.translate(-100, -200);
		drawAxis(g2, Color.RED);
		g2.setColor(Color.RED);
		g2.draw(shape1);
	}

	public void paintComponent5(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		g2.translate(60, 60);
		drawAxis(g2, Color.BLUE);

		// Draw of a square
		Shape shape1 = new Rectangle2D.Double(100, 200, 50, 50);
		g2.setColor(Color.BLUE);
		g2.fill(shape1);
		g2.draw(shape1);

		// Composition of transformations to rotate the square
		// around point (100, 200)
		// Notice that the axes are not transformed because the
		// composition is applied only to the shape.
		AffineTransform at = new AffineTransform();
		at.translate(100, 200);
		at.rotate(Math.PI / 6);
		at.translate(-100, -200);
		shape1 = at.createTransformedShape(shape1);

		drawAxis(g2, Color.RED);
		g2.setColor(Color.RED);
		g2.draw(shape1);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.translate(100, 100);
		Shape e = new Ellipse2D.Double(300, 200, 200, 100);
		g2.setColor(new Color(160, 160, 160));
		g2.fill(e);

		AffineTransform transform = new AffineTransform();

		// transform.translate(400,250);
		// transform.rotate(Math.PI / 6.0);
		transform.rotate(Math.PI / 6.0, 400, 250);
		// transform.translate(-400,-250);

		e = transform.createTransformedShape(e);
		g2.setColor(new Color(100, 100, 100));
		g2.draw(e);
	}

	// Auxiliary functions
	private LinkedList<Graphics2D> stack = new LinkedList<Graphics2D>();

	public Graphics2D push(Graphics2D g2) {
		this.stack.addFirst(g2); // Save for future use
		return (Graphics2D) g2.create(); // Copy the object
	}

	public Graphics2D pop() {
		return this.stack.removeFirst(); // Restores the saved object
	}

	void drawAxis(Graphics2D g2, Color c) {
		g2.setColor(c);
		g2.drawLine(-400, 0, 400, 0);
		g2.drawLine(0, -400, 0, 400);
	}
}
