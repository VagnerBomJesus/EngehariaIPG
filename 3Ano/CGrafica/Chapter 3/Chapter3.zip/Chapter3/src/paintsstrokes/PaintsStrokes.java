package paintsstrokes;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cglib2d.shapes.Arrow;

public class PaintsStrokes extends JFrame {

	public static void main(String[] args) {
		JFrame frame = new PaintsStrokes();
		frame.setTitle("Paints & Strokes");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		JScrollPane jsp = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		jsp.setVisible(true);
		frame.add(jsp);
		
		//frame.getContentPane().add(panel);
		frame.setSize(400,400);  
		//frame.pack();
		frame.setVisible(true);
	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(800, 800));
		setBackground(Color.WHITE);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		Arrow arrow = new Arrow(100, 50, 200, 200);

        // Save original state of the coordinate system to reset it later.
		AffineTransform at = g2.getTransform();

		// Color Paint
		g2.setPaint(Color.BLUE);
		g2.fill(arrow);
		g2.setPaint(Color.RED);
		g2.draw(arrow);

		// Gradient Paint 1
		GradientPaint gp = new GradientPaint(100, 50 + 100, Color.RED, 100 + 200, 50 + 100, Color.BLUE);
		g2.setPaint(gp);
		
		g2.translate(0, 250);
		g2.fill(arrow);
		g2.setColor(Color.GREEN);
		g2.drawLine(100, 50 + 100, 100 + 200, 50 + 100);

		// Gradient Paint 2
		gp = new GradientPaint(100, 50 + 100, Color.RED, 100 + 100, 50 + 100, Color.BLUE, true);
		g2.setPaint(gp);
		
		g2.translate(0, 250);
		g2.fill(arrow);
		g2.setColor(Color.GREEN);
		g2.drawLine(100, 50 + 100, 100 + 100, 50 + 100);

		// Gradient Paint 3
		gp = new GradientPaint(100, 50, Color.RED, 100 + 200, 50 + 200, Color.BLUE);
		g2.setPaint(gp);
		
		g2.translate(0, 250);
		g2.fill(arrow);
		g2.setColor(Color.GREEN);
		g2.drawLine(100, 50, 100 + 200, 50 + 200);

		// Reset of the coordinate system.
		g2.setTransform(at);

		// Texture Paint 
		BufferedImage image = null;
		URL url = getClass().getClassLoader().getResource("images/Smile.jpg");
		try {
			image = ImageIO.read(url);
		} catch (IOException ex) {
			ex.printStackTrace();
		}

		Rectangle2D anchor = new Rectangle2D.Double(0, 0, image.getWidth() / 3, image.getHeight() / 3);
		TexturePaint tp = new TexturePaint(image, anchor);
		g2.setPaint(tp);

		g2.translate(250, 0);
		g2.fill(arrow);
		g2.setPaint(Color.RED);
		g2.draw(arrow);

		// Stroke 1
		Stroke s = new BasicStroke(5);
		g2.setStroke(s);
		g2.setPaint(tp);
		
		g2.translate(0, 250);
		g2.fill(arrow);
		g2.setPaint(Color.RED);
		g2.draw(arrow);

		// Stroke 2
		float dash[] = {3, 10};
		s = new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, dash, 0);
		g2.setStroke(s);
		g2.setPaint(tp);

		g2.translate(0, 250);
		g2.fill(arrow);
		g2.setPaint(Color.RED);
		g2.draw(arrow);
	}
}
