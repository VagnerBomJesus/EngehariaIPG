package ex3_4;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.TexturePaint;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import cglib2d.utils.Utils;

public class Ex3_4 extends JFrame {

	public static void main(String[] args) {
		JFrame frame = new Ex3_4();
		frame.setTitle("Ex3_4");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}

}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(400, 400));
		setBackground(Color.WHITE);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		Font font = new Font("Serif", Font.BOLD, 300);
		FontRenderContext frc = g2.getFontRenderContext();
		
		Shape shapeN = font.createGlyphVector(frc, "N").getOutline();
		Shape shapeY = font.createGlyphVector(frc, "Y").getOutline();
		
		Area shape = new Area(shapeN);
		shape.add(new Area(shapeY));
		
		// Translate the origin of the coordinate system to the midle of the pannel.
		g2.translate(200, 200);
		//drawAxis(g2, Color.BLUE);
		//Utils.drawAxis(g2, Color.GREEN, 200, 3);
		
		int wS = shape.getBounds().width;
		int hS = shape.getBounds().height;
		int x = shape.getBounds().x;
		int y = shape.getBounds().y;
		
		// Center the shape at the origin.
		AffineTransform at = new AffineTransform();
		at.setToTranslation(-wS/2, hS/2);
		//shape = at.createTransformedShape(shape);
		shape = shape.createTransformedArea(at);
		
		//g2.setColor(Color.RED);
		//g2.draw(shapeN);
		//g2.draw(shapeY);
		//g2.setPaint(new GradientPaint(x, y, Color.RED, x + wS,  y + hS, Color.BLUE));
		g2.setPaint(new TexturePaint(Utils.readImage(this, "images/Brick_Wall.jpg"), new Rectangle2D.Double(0, 0, wS, hS)));
		//g2.draw(shape);
		g2.fill(shape);
	}
    
	// This function has became a static method of the CGLib2D Utils class. 
	void drawAxis(Graphics2D g2, Color c) {
		g2.setColor(c);
		g2.drawLine(-400, 0, 400, 0);
		g2.drawLine(0, -400, 0, 400);
	}
	
	// This function has became a static method of the CGLib2D Utils class.
	BufferedImage readImage(String imageFileName) {
		BufferedImage bi = null;
		URL imageSrc = null;

		try {
			imageSrc = getClass().getClassLoader().getResource(imageFileName);
			bi = ImageIO.read(imageSrc);
		} catch (IOException e) {
			System.out.println("Image could not be read");
		}
		return bi;
	}
}
