package ex3_3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ex3_3 extends JFrame {

	public static void main(String[] args) {
		JFrame frame = new Ex3_3();
		frame.setTitle("Ex3_3");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(800, 800));
		setBackground(Color.WHITE);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		// g2.translate(200, 200);
		drawAxis(g2, Color.BLACK);

		AffineTransform at = new AffineTransform();
		at.setToTranslation(100, 300);
		g2.setTransform(at);
		drawAxis(g2, Color.RED);
		flower(g2);

		at.setToTranslation(300, 100);
		// at.setToIdentity();
		// at.translate(300, 100);
		at.scale(0.5, 0.5);
		g2.setTransform(at);
		drawAxis(g2, Color.BLUE);
		flower(g2);

		// at.setToIdentity();
		// at.translate(475, 475);
		at.setToTranslation(475, 475);
		at.rotate(Math.toRadians(360 / 16));
		at.scale(2, 2);

		g2.setTransform(at);
		drawAxis(g2, Color.BLACK);
		flower(g2);
	}

	private void flower(Graphics2D g2) {
		int n = 8;

		Shape c = new Ellipse2D.Double(-20, -20, 40, 40);
		g2.setColor(Color.RED);
		g2.fill(c);

		Shape p = new Ellipse2D.Double(-20, 0, 40, 100);

		AffineTransform at = new AffineTransform();
		at.setToTranslation(0, 23);
		p = at.createTransformedShape(p);
		g2.setColor(Color.BLUE);
		g2.fill(p);

		for (int i = 0; i < n - 1; i++) {
			at.setToRotation(Math.toRadians(360 / n));
			// at.setToIdentity();
			// at.rotate(Math.toRadians(360/n));
			p = at.createTransformedShape(p);
			g2.fill(p);
		}
	}

	void drawAxis(Graphics2D g2, Color c) {
		g2.setColor(c);
		g2.drawLine(-400, 0, 400, 0);
		g2.drawLine(0, -400, 0, 400);
	}
}
