package ex3_2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ex3_2 extends JFrame {

	public static void main(String[] args) {
		JFrame frame = new Ex3_2();
		frame.setTitle("Ex3_2");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new MyPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}

class MyPanel extends JPanel {

	public MyPanel() {
		setPreferredSize(new Dimension(400, 400));
		setBackground(Color.WHITE);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		Shape hero = new Ellipse2D.Double(-20, -20, 40, 40);
		Shape prize = new Rectangle2D.Double(-25, -25, 50, 50);
		Shape bar = new Rectangle2D.Double(-100, -10, 200, 20);
			    	
		AffineTransform at = new AffineTransform();
		
		// Position of the bar
		at.translate(200, 200);
		bar = at.createTransformedShape(bar);
		g2.setColor(Color.RED);
		g2.fill(bar);
		
		// Position of the prize
		at.setToIdentity();
		at.translate(200,  150);
		//at.setToTranslation(200, 150);
		at.rotate(Math.toRadians(45));
		prize = at.createTransformedShape(prize);

		g2.setColor(Color.BLUE);
		g2.fill(prize);
				
		// Position of the hero
		at.setToIdentity();
		at.translate(50, 400-40);
		at.scale(2, 2);
		hero = at.createTransformedShape(hero);
    	g2.setColor(Color.YELLOW);
		g2.fill(hero);
	}
}