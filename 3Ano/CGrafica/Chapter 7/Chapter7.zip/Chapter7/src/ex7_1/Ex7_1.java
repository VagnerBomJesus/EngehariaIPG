package ex7_1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.event.WindowEvent;

import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.Background;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.Material;
import javax.media.j3d.PointLight;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.universe.SimpleUniverse;

import shapes.Axes;
import shapes.Floor;
import shapes.FloorLamp;
import shapes.Table;

public class Ex7_1 extends Frame {

	// Global bounds
	BoundingSphere bounds = new BoundingSphere();

	public static void main(String[] args) {
		Frame frame = new Ex7_1();
		frame.setPreferredSize(new Dimension(800, 800));
		frame.setTitle("Simple 3D Scene");
		frame.pack();
		frame.setVisible(true);
	}

	// The Frame class doesn't have a
	// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// A possible solution is to override the processWindowEvent method.
	protected void processWindowEvent(WindowEvent e) {
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			System.exit(0);
		}
	}

	public Ex7_1() {
		// Create a Canvas3D
		GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
		Canvas3D cv = new Canvas3D(gc);

		// Add the canvas to the frame
		setLayout(new BorderLayout());
		add(cv, BorderLayout.CENTER);

		// Create the scene graph
		BranchGroup bg = createSceneGraph();
		bg.compile();

		// Create the root of the scene graph with a standard nominal view
		SimpleUniverse su = new SimpleUniverse(cv);
		su.getViewingPlatform().setNominalViewingTransform();

		// Add the scene graph to the root
		su.addBranchGraph(bg);

		// Add a OrbitBehavior to control the view with the mouse
		OrbitBehavior orbit = new OrbitBehavior(cv);
		orbit.setSchedulingBounds(bounds);
		su.getViewingPlatform().setViewPlatformBehavior(orbit);
	}

	private BranchGroup createSceneGraph() {
		BranchGroup root = new BranchGroup();

		// Axes
		root.addChild(new Axes(new Color3f(Color.RED), 3, 0.5f));

		// Floor
		root.addChild(new Floor(10, -1, 1, new Color3f(Color.DARK_GRAY), new Color3f(Color.WHITE), true));

		// Table
		Appearance app = new Appearance();
		app.setMaterial(new Material());
		Table table = new Table(app);

		Transform3D tr = new Transform3D();
		tr.setScale(0.5f);
		tr.setTranslation(new Vector3f(0.5f, 0f, 0f));
		TransformGroup tg = new TransformGroup(tr);
		tg.addChild(table);
		root.addChild(tg);

		// Lamp
		FloorLamp floorLamp = new FloorLamp(app);
		tr = new Transform3D();
		tr.setScale(0.5f);
		tr.setTranslation(new Vector3f(-0.3f, 0f, 0f));
		tg = new TransformGroup(tr);
		tg.addChild(floorLamp);
		root.addChild(tg);

		// Background
		Background background = new Background(new Color3f(Color.LIGHT_GRAY));
		background.setApplicationBounds(bounds);
		root.addChild(background);

		// Lights
		AmbientLight aLight = new AmbientLight(true, new Color3f(Color.WHITE));
		aLight.setInfluencingBounds(bounds);
		root.addChild(aLight);

		PointLight pLight = new PointLight(new Color3f(Color.YELLOW), new Point3f(3f, 3f, 3f), new Point3f(1f, 0f, 0f));
		pLight.setInfluencingBounds(bounds);
		root.addChild(pLight);

		return root;
	}
}
