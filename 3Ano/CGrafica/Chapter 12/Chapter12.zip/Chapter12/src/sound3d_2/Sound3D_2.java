package sound3d_2;

import com.sun.j3d.audioengines.javasound.JavaSoundMixer;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.loaders.objectfile.ObjectFile;
import java.net.URL;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.image.*;
import com.sun.j3d.utils.universe.*;

import javax.media.j3d.*;
import javax.vecmath.*;
import java.io.*;
import javax.imageio.*;
import com.sun.j3d.utils.behaviors.mouse.*;
import java.applet.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Sound3D_2 extends Frame {

	public static void main(String[] args) {
		Frame frame = new Sound3D_2();
		frame.setPreferredSize(new Dimension(600, 600));
		frame.setTitle("Sound3D_2");
		frame.pack();
		frame.setVisible(true);
	}

	// The Frame class doesn't have a
	// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// A possible solution is to override the processWindowEvent method.
	protected void processWindowEvent(WindowEvent e) {
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			System.exit(0);
		}
	}

	public Sound3D_2() {
		// Create canvas
		GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
		Canvas3D cv = new Canvas3D(gc);
		setLayout(new BorderLayout());
		add(cv, BorderLayout.CENTER);
		SimpleUniverse su = new SimpleUniverse(cv);

		// System.setProperty("j3d.audiodevice",
		// "com.sun.j3d.audioengines.javasound.JavaSoundMixer");
		// AudioDevice audioDev = su.getViewer().createAudioDevice();

		AudioDevice audioDev = new JavaSoundMixer(su.getViewer().getPhysicalEnvironment());
		audioDev.initialize();

		BranchGroup bg = createSceneGraph();
		bg.compile();
		su.getViewingPlatform().setNominalViewingTransform();
		su.addBranchGraph(bg);
	}

	public BranchGroup createSceneGraph() {
		// root
		BranchGroup root= new BranchGroup();
		Transform3D trans = new Transform3D();
		trans.setTranslation(new Vector3d(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5));
		trans.setScale(0.3);
		
		TransformGroup objTg = new TransformGroup(trans);
		objTg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		objTg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		objTg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		root.addChild(objTg);

		// visual object
		// Appearance ap = new Appearance();
		// ap.setMaterial(new Material());
		// Shape3D shape = new Shape3D(new Tetrahedron(), ap);
		// objTrans.addChild(shape);
		objTg.addChild(loadOBJ());

		// behaviors
		BoundingSphere bounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 10.0);

		// rotation
		MouseRotate rotator = new MouseRotate(objTg);
		rotator.setSchedulingBounds(bounds);
		root.addChild(rotator);
		// translation
		MouseTranslate translator = new MouseTranslate(objTg);
		translator.setSchedulingBounds(bounds);
		objTg.addChild(translator);
		// zoom
		MouseZoom zoom = new MouseZoom(objTg);
		zoom.setSchedulingBounds(bounds);
		objTg.addChild(zoom);

		BoundingSphere soundBounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 10.0);

		// Sound
		BackgroundSound bSound = new BackgroundSound();
		URL url = this.getClass().getClassLoader().getResource("images/river.wav");
		MediaContainer mc = new MediaContainer(url);
		bSound.setSoundData(mc);
		bSound.setLoop(Sound.INFINITE_LOOPS);
		bSound.setSchedulingBounds(soundBounds);
		bSound.setInitialGain(0.01f);
		bSound.setEnable(true);
		//root.addChild(bSound);

		PointSound pSound = new PointSound();
		url = this.getClass().getClassLoader().getResource("images/bird.wav");
		mc = new MediaContainer(url);
		pSound.setSoundData(mc);
		pSound.setLoop(Sound.INFINITE_LOOPS);
		pSound.setInitialGain(1f);
		float[] distances = { 1f, 10f };
		float[] gains = { 1f, 0.001f };
		pSound.setDistanceGain(distances, gains);
		pSound.setSchedulingBounds(soundBounds);
		pSound.setEnable(true);
		objTg.addChild(pSound);

		// Light
		AmbientLight light = new AmbientLight(true, new Color3f(Color.blue));
		light.setInfluencingBounds(bounds);
		root.addChild(light);
		PointLight ptlight = new PointLight(new Color3f(Color.white), new Point3f(0f, 0f, 2f),
				new Point3f(1f, 0.3f, 0f));
		ptlight.setInfluencingBounds(bounds);
		root.addChild(ptlight);

		// Background
		url = getClass().getClassLoader().getResource("images/clouds.jpg");
		BufferedImage bi = null;
		try {
			bi = ImageIO.read(url);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		ImageComponent2D image = new ImageComponent2D(ImageComponent2D.FORMAT_RGB, bi);
		Background background = new Background(image);
		background.setApplicationBounds(bounds);
		root.addChild(background);
		return root;
	}

	protected BranchGroup loadOBJ() {

		ObjectFile f1 = new ObjectFile();
		Scene s1 = null;

		URL url = this.getClass().getClassLoader().getResource("images/birdy.obj");
		try {
			s1 = f1.load(url);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}

		return s1.getSceneGroup();
	}
}