package shadow;

import javax.vecmath.*;

import java.applet.Applet;
import java.awt.*;
import java.awt.image.*;
import java.net.URL;
import java.io.*;

import javax.imageio.*;
import javax.media.j3d.*;

import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Shadow extends Applet {
  public static void main(String[] args) {
    new MainFrame(new Shadow(), 640, 480);
  }

  public void init() {
    // create canvas
    GraphicsConfiguration gc = SimpleUniverse.getPreferredConfiguration();
    Canvas3D cv = new Canvas3D(gc);
    setLayout(new BorderLayout());
    add(cv, BorderLayout.CENTER);
    BranchGroup bg = createSceneGraph();
    bg.compile();
    SimpleUniverse su = new SimpleUniverse(cv);
    su.getViewingPlatform().setNominalViewingTransform();
    su.addBranchGraph(bg);
  }
  
  private BranchGroup createSceneGraph() {
    BranchGroup root = new BranchGroup();
    //object
    Appearance ap = new Appearance();
    ap.setMaterial(new Material());
    Shape3D shape = new Dodecahedron();
    shape.setAppearance(ap);
    GeometryArray geom = (GeometryArray)shape.getGeometry();
    //transform
    Transform3D tr = new Transform3D();
    tr.rotY(-0.2);
    tr.setScale(0.2);
    TransformGroup tg = new TransformGroup(tr);
    root.addChild(tg);
    tg.addChild(shape);
    BoundingSphere bounds = new BoundingSphere(new Point3d(0,0,0),100);
    //light and background
    Background background = new Background(1.0f, 1.0f, 1.0f);
    background.setApplicationBounds(bounds);
    root.addChild(background);
    AmbientLight light = new AmbientLight(true, new Color3f(Color.red));
    light.setInfluencingBounds(bounds);
    root.addChild(light);
    Point3f lightPos = new Point3f(10f,3f,1f);
    PointLight ptlight = new PointLight(new Color3f(Color.green),
    lightPos, new Point3f(1f,0f,0f));
    ptlight.setInfluencingBounds(bounds);
    tg.addChild(ptlight);
    // wall
    Shape3D wall = createWall();
    tg.addChild(wall);
    // shadow
    GeometryArray shadow = createShadow(geom, lightPos, new Point3f(-2f, 3f, 1f));
    ap = new Appearance();
    ColoringAttributes colorAttr = new ColoringAttributes(0.1f, 0.1f, 0.1f, 
      ColoringAttributes.FASTEST);
    ap.setColoringAttributes(colorAttr);
    TransparencyAttributes transAttr = new TransparencyAttributes(
      TransparencyAttributes.BLENDED,0.35f);
    ap.setTransparencyAttributes(transAttr);
    PolygonAttributes polyAttr = new PolygonAttributes();
    polyAttr.setCullFace(PolygonAttributes.CULL_NONE);
    ap.setPolygonAttributes(polyAttr);
    shape = new Shape3D(shadow, ap);
    tg.addChild(shape);
    return root;
  }
  
  private Shape3D createWall() {
    URL url = getClass().getClassLoader().getResource("images/stone.jpg");
    BufferedImage bi = null;
    try {
      bi = ImageIO.read(url);
    } catch (IOException ex) {
      ex.printStackTrace();
    }
    ImageComponent2D image = new ImageComponent2D(ImageComponent2D.FORMAT_RGB, bi);
    Texture2D texture = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA,
    image.getWidth(), image.getHeight());
    texture.setImage(0, image);
    texture.setEnable(true);
    texture.setMagFilter(Texture.BASE_LEVEL_LINEAR);
    texture.setMinFilter(Texture.BASE_LEVEL_LINEAR);
    Appearance appear = new Appearance();
    appear.setTexture(texture);
    QuadArray rect = new QuadArray(4, QuadArray.COORDINATES |
      QuadArray.TEXTURE_COORDINATE_2);
    rect.setCoordinate(0, new Point3d(-2,3,2));
    rect.setCoordinate(1, new Point3d(-2,-3,2));
    rect.setCoordinate(2, new Point3d(-2,-3,-3));
    rect.setCoordinate(3, new Point3d(-2,3,-3));
    rect.setTextureCoordinate(0,0, new TexCoord2f(0f, 0f));
    rect.setTextureCoordinate(0,1, new TexCoord2f(0f, 1f));
    rect.setTextureCoordinate(0,2, new TexCoord2f(1f, 1f));
    rect.setTextureCoordinate(0,3, new TexCoord2f(1f, 0f));
    return new Shape3D(rect, appear);
  }
  
  private GeometryArray createShadow(GeometryArray ga, Point3f light, Point3f plane) {
    
	// A geometria do pol�gono que simula a sombra vai ser criado com IndexedTriangleArray
	// pelo que a geometria do objeto � transformada para esse tipo, de modo a depois extrair
	// caracteristicas da geometria do objeto para construir a geometria da sombra, como por
	// exemplo, o n�mero de v�rtices.  
	
	// The geometry of the polygon that simulates the shadow will be created with IndexedTriangleArray
	// so the geometry of the object is transformed for this type, in order to later extract
	// characteristics of object geometry to construct shadow geometry, such as the number of vertices.
	GeometryInfo gi = new GeometryInfo(ga);
    gi.convertToIndexedTriangles();
    IndexedTriangleArray ita = (IndexedTriangleArray)gi.getIndexedGeometryArray();
    
    // Determinar um vetor entre a fonte de luz e o plano de proje��o da sombra para obter 
    // a dist�ncia entre os dois. 
    
    // Determine a vector between the light source and the shadow projection plane to obtain
    // the distance between the two.
    Vector3f v = new Vector3f();
    v.sub(plane, light);
    
    // Construir a matriz da transforma��o de proje��o para a forma standard.
    
    // Construct the matrix of the projection transformation to the standard form.
    double[] mat = new double[16];
    for (int i = 0; i < 16; i++) {
      mat[i] = 0;
    }
    mat[0] = 1;
    mat[5] = 1;
    mat[10] = 1-0.001;
    mat[14] = -1/v.length();    
    Transform3D proj = new Transform3D();
    proj.set(mat);
    
    // Acrescentar a transforma��o U e U-1 dada por lookat para transformar casos gen�ricos 
    // na forma standard.
    
    // Add the U and U-1 transformation given by lookat to transform generic cases
    // into standard form.
    Transform3D u = new Transform3D();
    u.lookAt(new Point3d(light), new Point3d(plane), new Vector3d(0,1,0));
    proj.mul(u);
    Transform3D tr = new Transform3D();
    u.invert();
    tr.mul(u, proj);
    
    // Criar a gemetria do pol�gono da sombra com o mesmo n�mero de v�rtices e �ndices da
    // geometria do objeto.
    
    // Create the polygon of the shadow with the same number of vertices and indexes of the
    // geometry of the object.
    int n = ita.getVertexCount();
    int count = ita.getIndexCount();
    IndexedTriangleArray shadow = new IndexedTriangleArray(n, 
      GeometryArray.COORDINATES, count);
    
    // Calcular as coordenadas dos v�rtices do pol�gono da sombra aplicando a transforma��o 
    // criada anteriormente aos v�rtices do objeto. 
    
    // Calculate the coordinates of the vertices of the shadow polygon by applying the transformation
    // created before, to the vertices of the object.
    for (int i = 0; i < n; i++) {
      Point3d p = new Point3d();
      ga.getCoordinate(i, p);
      Vector4d v4 = new Vector4d(p);
      v4.w = 1;
      tr.transform(v4);
      Point4d p4 = new Point4d(v4);
      p.project(p4);
      shadow.setCoordinate(i, p);
    }
    
    // Copiar os �ndices de coordenadas dos v�rtices.
    // Notar que os �ndices s�o iguais, o que difere s�o as coordenadas dos v�rtices que s�o
    // transformados pela transforma��o composta.
    
    // Copy the coordinate indices of the vertices.
    // Note that the indices are equal, what differs are the coordinates of the vertices that are
    // transformed by the composite transformation.
    int[] indices = new int[count];
    ita.getCoordinateIndices(0, indices);
    shadow.setCoordinateIndices(0, indices);
    return shadow;
  }
}
