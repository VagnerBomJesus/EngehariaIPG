package com.sun.j3d.utils.scenegraph.io.state.com.sun.j3d.utils.image;

import java.net.URL;

public interface ImageComponent2DURLIOListener {
  ImageComponent2DURL createImageComponent(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, URL paramURL);
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\robot.jar!\com\sun\j3\\utils\scenegraph\io\state\com\sun\j3\\utils\image\ImageComponent2DURLIOListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */