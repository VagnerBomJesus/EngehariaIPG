package javax.media.j3d;

public interface GeometryUpdater {
  void updateData(Geometry paramGeometry);
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\robot.jar!\javax\media\j3d\GeometryUpdater.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */