package com.sun.j3d.exp.swing.impl;

public interface AutoOffScreenCanvas3D {}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkmosaicfloor.jar!\com\sun\j3d\exp\swing\impl\AutoOffScreenCanvas3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */