/*    */ package javax.media.j3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImageComponentUpdateInfo
/*    */ {
/* 20 */   int x = 0;
/* 21 */   int y = 0;
/* 22 */   int z = 0;
/* 23 */   int width = 0;
/* 24 */   int height = 0;
/* 25 */   int updateMask = 0;
/*    */   boolean entireImage = false;
/*    */ }


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkmosaicfloor.jar!\javax\media\j3d\ImageComponentUpdateInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */