/*    */ package javax.media.j3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalSceneGraphException
/*    */   extends RuntimeException
/*    */ {
/*    */   public IllegalSceneGraphException() {}
/*    */   
/* 38 */   public IllegalSceneGraphException(String paramString) { super(paramString); }
/*    */ }


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkmosaicfloor.jar!\javax\media\j3d\IllegalSceneGraphException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */