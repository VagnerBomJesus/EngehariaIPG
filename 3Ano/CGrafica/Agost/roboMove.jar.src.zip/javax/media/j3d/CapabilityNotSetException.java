/*    */ package javax.media.j3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CapabilityNotSetException
/*    */   extends RestrictedAccessException
/*    */ {
/*    */   public CapabilityNotSetException() {}
/*    */   
/* 34 */   public CapabilityNotSetException(String paramString) { super(paramString); }
/*    */ }


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\roboMove.jar!\javax\media\j3d\CapabilityNotSetException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */