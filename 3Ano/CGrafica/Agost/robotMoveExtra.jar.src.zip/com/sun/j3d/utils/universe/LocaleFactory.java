package com.sun.j3d.utils.universe;

import javax.media.j3d.HiResCoord;
import javax.media.j3d.Locale;
import javax.media.j3d.VirtualUniverse;

public interface LocaleFactory {
  Locale createLocale(VirtualUniverse paramVirtualUniverse, HiResCoord paramHiResCoord);
  
  Locale createLocale(VirtualUniverse paramVirtualUniverse);
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\robotMoveExtra.jar!\com\sun\j3\\util\\universe\LocaleFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */