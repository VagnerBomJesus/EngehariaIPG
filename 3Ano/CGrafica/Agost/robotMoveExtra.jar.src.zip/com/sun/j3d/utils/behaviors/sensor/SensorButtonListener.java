package com.sun.j3d.utils.behaviors.sensor;

public interface SensorButtonListener {
  void pressed(SensorEvent paramSensorEvent);
  
  void released(SensorEvent paramSensorEvent);
  
  void dragged(SensorEvent paramSensorEvent);
  
  void clicked(SensorEvent paramSensorEvent);
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\robotMoveExtra.jar!\com\sun\j3\\utils\behaviors\sensor\SensorButtonListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */