/*    */ package javax.media.j3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AssertionFailureException
/*    */   extends RuntimeException
/*    */ {
/*    */   AssertionFailureException() {}
/*    */   
/* 32 */   AssertionFailureException(String paramString) { super(paramString); }
/*    */ }


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\robotMoveExtra.jar!\javax\media\j3d\AssertionFailureException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */