package com.sun.j3d.utils.behaviors.sensor;

public interface SensorReadListener {
  void read(SensorEvent paramSensorEvent);
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkoctahedron.jar!\com\sun\j3\\utils\behaviors\sensor\SensorReadListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */