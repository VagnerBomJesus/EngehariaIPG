package com.sun.j3d.utils.geometry;

class PntNode {
  int pnt;
  
  int next;
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkoctahedron.jar!\com\sun\j3\\utils\geometry\PntNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */