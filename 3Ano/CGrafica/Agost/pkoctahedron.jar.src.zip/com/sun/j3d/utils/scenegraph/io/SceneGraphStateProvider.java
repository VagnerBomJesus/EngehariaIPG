package com.sun.j3d.utils.scenegraph.io;

import com.sun.j3d.utils.scenegraph.io.state.javax.media.j3d.SceneGraphObjectState;

public interface SceneGraphStateProvider {
  Class<? extends SceneGraphObjectState> getStateClass();
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkoctahedron.jar!\com\sun\j3\\utils\scenegraph\io\SceneGraphStateProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */