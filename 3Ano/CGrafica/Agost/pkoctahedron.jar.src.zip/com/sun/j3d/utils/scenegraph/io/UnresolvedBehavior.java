/*    */ package com.sun.j3d.utils.scenegraph.io;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.media.j3d.Behavior;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnresolvedBehavior
/*    */   extends Behavior
/*    */ {
/* 58 */   public void initialize() { setEnable(false); }
/*    */   
/*    */   public void processStimulus(Enumeration paramEnumeration) {}
/*    */ }


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkoctahedron.jar!\com\sun\j3\\utils\scenegraph\io\UnresolvedBehavior.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */