package com.sun.j3d.loaders.lw3d;

import java.util.Vector;
import javax.media.j3d.TransformGroup;

interface LwsPrimitive {
  Vector getObjectBehaviors();
  
  TransformGroup getObjectNode();
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkcube.jar!\com\sun\j3d\loaders\lw3d\LwsPrimitive.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */