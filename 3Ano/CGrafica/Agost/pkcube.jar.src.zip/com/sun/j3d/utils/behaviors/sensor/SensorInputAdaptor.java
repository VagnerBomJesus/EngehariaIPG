package com.sun.j3d.utils.behaviors.sensor;

public class SensorInputAdaptor implements SensorButtonListener, SensorReadListener {
  public void pressed(SensorEvent paramSensorEvent) {}
  
  public void released(SensorEvent paramSensorEvent) {}
  
  public void dragged(SensorEvent paramSensorEvent) {}
  
  public void clicked(SensorEvent paramSensorEvent) {}
  
  public void read(SensorEvent paramSensorEvent) {}
}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkcube.jar!\com\sun\j3\\utils\behaviors\sensor\SensorInputAdaptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */