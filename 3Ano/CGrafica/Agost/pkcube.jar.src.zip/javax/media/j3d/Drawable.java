package javax.media.j3d;

interface Drawable {}


/* Location:              C:\Users\Good Shape Code\OneDrive\IPG-ESTG-1920\SEMESTER1\CG\Outros\pkcube.jar!\javax\media\j3d\Drawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */